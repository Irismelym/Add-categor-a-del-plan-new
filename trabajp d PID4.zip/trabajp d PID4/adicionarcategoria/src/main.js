
import { createApp } from 'vue'
import App from './App.vue'
import './style.css' // si quieres usar estilos globales opcionales

createApp(App).mount('#app')
