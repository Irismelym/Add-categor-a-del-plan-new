<template>
  <div class="form-container">
    <h2>Adicionar categoría del plan</h2>
    <form @submit.prevent="handleSubmit">
      <div class="form-group">
        <label>Denominación<span class="required">*</span></label>
        <input type="text" v-model="form.denomination" required />
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Fecha inicio<span class="required">*</span></label>
          <input type="date" v-model="form.startDate" required />
        </div>
        <div class="form-group">
          <label>Fecha fin:</label>
          <input type="date" v-model="form.endDate" />
        </div>
      </div>

      <div class="form-group">
        <label>
          <input type="checkbox" v-model="form.structure" />
          Estructura
        </label>
      </div>

      <div class="form-group">
        <label>Descripción:</label>
        <div class="toolbar">
          <select v-model="form.font">
            <option>Helvetica</option>
            <option>Arial</option>
            <option>Times New Roman</option>
          </select>
          <button type="button"><b>B</b></button>
          <button type="button"><i>I</i></button>
          <button type="button"><u>U</u></button>
          <button type="button"><span style="color: yellow">T</span></button>
        </div>
        <textarea v-model="form.description" rows="5"></textarea>
      </div>

      <div class="buttons">
        <button type="button" class="cancel">Cancelar</button>
        <button type="button" class="apply">Aplicar</button>
        <button type="submit" class="accept">Aceptar</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { reactive } from 'vue'

const form = reactive({
  denomination: '',
  startDate: '',
  endDate: '',
  structure: false,
  font: 'Helvetica',
  description: ''
})

function handleSubmit() {
  alert('Formulario enviado:\n' + JSON.stringify(form, null, 2))
}
</script>

<style scoped>
.form-container {
  max-width: 600px;
  margin: 2rem auto;
  background: #f5f0f7;
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 1.5rem;
  font-family: sans-serif;
}

h2 {
  margin-bottom: 1rem;
  color: #5e338c;
}

.form-group {
  margin-bottom: 1rem;
}

.form-row {
  display: flex;
  gap: 1rem;
}

label {
  display: block;
  margin-bottom: 0.25rem;
}

.required {
  color: red;
  margin-left: 0.2rem;
}

input[type="text"],
input[type="date"],
textarea,
select {
  width: 100%;
  padding: 0.5rem;
  font-size: 1rem;
  box-sizing: border-box;
  border-radius: 4px;
  border: 1px solid #ccc;
}

textarea {
  resize: vertical;
}

.toolbar {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
}

.toolbar button {
  padding: 0.25rem 0.5rem;
  font-size: 1rem;
}

.buttons {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 1.5rem;
}

.cancel {
  background-color: #c0392b;
  color: white;
}

.apply {
  background-color: #8e44ad;
  color: white;
}

.accept {
  background-color: #27ae60;
  color: white;
}

button {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>
